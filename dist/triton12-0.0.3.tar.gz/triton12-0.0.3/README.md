# Tritons-dozen
Data loading and analyzing functions made for T12 data.
